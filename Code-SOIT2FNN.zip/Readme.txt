%% **********************Code Description********************************

This repository contains the supplementary code submitted with the manuscript "A Self-organizing Interval Type-2 Fuzzy Neural Network for Multi-Step Time Series Prediction", which is under review for Applied Soft Computing.


***Note***:
To adhere to academic writing standards, we have adjusted some of the symbols in the submitted manuscript. As a result, certain symbols in this code may differ from those used in the manuscript.
In this file, we have added comments to indicate discrepancies between the symbols in the code and the manuscript. 
Additionally, we have also added comments to important sections of the code to help reviewers better understand the implementation. 
However, due to time constraints, some comments may be incomplete. We kindly ask reviewers to refer to the original text for clarification.  

This is a draft version of the code. After the article is officially published, we will refine the code (addressing all the above issues) and upload the completed version to the GitHub repository (https://github.com/FLYao123) for readers' reference.

%% ******************** How to run *******************************

Training: You can start model training by running Main_training.m in this directory. By default, the model is trained on the Chaotic time series dataset. Optionally, we have also included a microgrid dataset (containing price and unmet power data) in the folder. You can replace the default dataset following the comments in the code.
Test:  You can perform model testing by running Main_test.m. By default, the test is conducted on the Chaotic time series dataset. The trained weights for the Chaotic time series clean dataset are preserved in "Weights". Optionally, you can also retrain the model for both chaotic and microgrid examples before testing.


%% ************** Other available reference code *****************
In this repository, we have primarily organized and annotated the IT2FNN-MO code, as shown in Main_training.m and Main_test.m.
For reference, preliminary versions of IT2FNN-SW and IT2FNN-PM are available in the IT2FNNP2 and IT2FNNP1 directories. These drafts can be used for reference.

 Once the paper is accepted, we will refine and upload these additional code files to GitHub as well.