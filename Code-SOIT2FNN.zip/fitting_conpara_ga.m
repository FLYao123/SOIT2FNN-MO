function [optimizedParams, residuals] = fitting_conpara_ga(X, y_true, I, con_par, qlqr, rule_num, samp_num, R_vector_up, R_vector_lo, sum_R)
    % 初始参数向量
    
    initialparas = zeros(1, 2 * rule_num * (I + 1) + 2);
    for ii = 1:rule_num
        initialparas((ii-1) * 2 * (I + 1) + 1:((ii-1) * 2 + 1) * (I + 1)) = con_par(:,:,1,ii); % C
        initialparas(((ii-1) * 2 + 1) * (I + 1) + 1:ii * 2 * (I + 1)) = con_par(:,:,2,ii); % S
    end

    initialparas(end-1) = qlqr(1); % ql
    initialparas(end) = qlqr(2); % qr

    % 定义参数的范围
    lb = [-Inf(1, 2 * rule_num * (I + 1)), 0, 0]; % 下界，ql 和 qr 在 [0, 1] 区间内
    ub = [Inf(1, 2 * rule_num * (I + 1)), 1, 1]; % 上界，ql 和 qr 在 [0, 1] 区间内

    % 使用遗传算法进行全局优化
    options = optimoptions('ga', 'Display', 'iter');
    [optimizedParams, fval] = ga(@(params) objectiveFunction(params, X, y_true, rule_num, samp_num, R_vector_up, R_vector_lo, sum_R, I), ...
        numel(initialparas), [], [], [], [], lb, ub, [], options);

    % 打印优化后的参数
    disp('优化后的参数:');
    disp(optimizedParams);

    residuals = objectiveFunction(optimizedParams, X, y_true, rule_num, samp_num, R_vector_up, R_vector_lo, sum_R, I);
end

function error = objectiveFunction(params, X, y_true, rule_num, samp_num, R_vector_up, R_vector_lo, sum_R, I)
    y_pred = nonlinearFunction(params, X, rule_num, samp_num, R_vector_up, R_vector_lo, sum_R, I);
    error = norm(y_true - y_pred); % 可根据具体问题定义误差函数
end

function y = nonlinearFunction(params, X, rule_num, samp_num, R_vector_up, R_vector_lo, sum_R, I)
    yl_list = zeros(rule_num, samp_num);
    yr_list = zeros(rule_num, samp_num);
    ql = params(end-1);
    qr = params(end);
    for ii = 1:rule_num
        c = params((ii-1) * 2 * (I + 1) + 1:((ii-1) * 2 + 1) * (I + 1));
        s = params(((ii-1) * 2 + 1) * (I + 1) + 1:ii * 2 * (I + 1));
        X_with_bias = [ones(1, samp_num); X'];
        yl = c * X_with_bias - s * abs(X_with_bias);
        yr = c * X_with_bias + s * abs(X_with_bias);
        yl_list(ii, :) = yl; % rule_num * samp_num
        yr_list(ii, :) = yr; % rule_num * samp_num
    end
    % Type Reduction -----> yleft, yright
    yleft = ((1-ql) * sum(R_vector_lo' .* yl_list, 1) + ql * sum(R_vector_up' .* yl_list,1)) ./ sum_R'; % 1 * samp_num
    yright = ((1-qr) * sum(R_vector_lo' .* yr_list, 1) + qr * sum(R_vector_up' .* yr_list,1)) ./ sum_R'; % 1 * samp_num
    %% Defuzzification -----> y
    y = (0.5 * (yleft + yright))';
end
